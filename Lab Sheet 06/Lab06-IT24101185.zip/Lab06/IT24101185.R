getwd()
setwd("C:\\Users\\IT24101185\\Desktop\\Lab06")
getwd()

##probability that 40 children are cured
dbinom(40,44,0.92)

##probability that less than or equal to 35 children are cured
pbinom(35,44,0.92, lower.tail  = TRUE)

##probability that at least 38 children are cured
1- pbinom(37,44,0.92,lower.tail = TRUE)
pbinom(37,44,0.92,lower.tail = FALSE)

##probability that between 40 and 42 (both inclusive) children are cured
pbinom(42,44,0.92,lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail = TRUE)

##Question 02
##Part 01
##random variable (X) in the problem
## is Number of babies born in a hospital given day

##probability that 6 babies will be born in this hospital tomorrow
dpois(6,5)

##probability of more than 6 babies be born in this hospital tomorrow
ppois(6,5, lower.tail = FALSE)



## Exercise
pbinom(46,50,0.85,lower.tail= FALSE)


#2
#i) Number of customer calls received in an hour
#ii) Poisson Distribution
#iii)
dpois(15,12)

