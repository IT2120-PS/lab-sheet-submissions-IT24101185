setwd("C:\\Users\\user\\Desktop\\Lab07PS")

getwd()

# i. Probability bus arrives within first 10 minutes
punif(10, min = 0, max = 30, lower.tail = TRUE)  # P(X <= 10)

# ii. Probability bus arrives after 7:20 a.m.
punif(20, min = 0, max = 30, lower.tail = FALSE) # P(X > 20)

# Probability repair takes at most 3 hours
pexp(3, rate = 0.5, lower.tail = TRUE)  # P(X <= 3)

# Probability repair exceeds 4 hours
pexp(4, rate = 0.5, lower.tail = FALSE) # P(X > 4)

# Probability repair takes between 2 and 4 hours
pexp(4, rate = 0.5) - pexp(2, rate = 0.5)  # P(2 < X < 4)

#Probability of fever (temperature >= 37.9)
1 - pnorm(37.9, mean = 36.8, sd = 0.4)  # P(X >= 37.9)

#Probability temperature between 36.4 and 36.9
pnorm(36.9, mean = 36.8, sd = 0.4) - pnorm(36.4, mean = 36.8, sd = 0.4)  # P(36.4 < X < 36.9)

#Temperature below which 1.2% fall
qnorm(0.012, mean = 36.8, sd = 0.4)  # P(X < b) = 0.012

#Temperature above which 1.0% fall
qnorm(0.01, mean = 36.8, sd = 0.4, lower.tail = FALSE)  # P(X > b) = 0.01
