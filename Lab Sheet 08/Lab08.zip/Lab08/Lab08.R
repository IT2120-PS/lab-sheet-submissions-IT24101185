getwd ()
setwd ("C:\\Users\\IT24101185\\Documents\\Lab08")
getwd()
data <-read.table("Exercise - LaptopsWeights.txt",header = TRUE)

fix(data)
attach(data)SS


popmn<-mean(Weight.kg.)
popmn

popsd<-sd(Weight.kg.)
popsd

samples <- c()
n <- c()

for (i in 1:25) {
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste("s", i, sep = ""))
}
n
colnames(samples) = n

#3
s.means <- apply(samples, 2, mean)
s.means
s.sds <- apply(samples, 2, sd)
s.vars

# Mean and SD of Sample Means
sample_mean<-mean(s.means)
sample_mean
sample_sds<-sd(s.means)
sample_sds





